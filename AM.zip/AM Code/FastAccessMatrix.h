// FastAccessMatrix.h: interface for the CFastAccessMatrix class.
// Carlos J. Cela, 2006
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FASTACCESSMATRIX_H__9F05D3BB_5D44_472A_A5BF_8D3ED872BBBC__INCLUDED_)
#define AFX_FASTACCESSMATRIX_H__9F05D3BB_5D44_472A_A5BF_8D3ED872BBBC__INCLUDED_
#pragma warning (disable:4786)

#include <map>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFastAccessMatrix  
{
public:
	CFastAccessMatrix();
	virtual ~CFastAccessMatrix();

	// Fill method
	void set(int col, int row, double value);

	// Random get SLOW
	double get(int col, int row);
	void get(int col, int row, double& value);

	// Enumeration methods - VERY FAST

	// Start enumeration. Returns first row #.
	int resetEnumeration();

	// Advance to row
	int nextRow();
	bool gotoRow(int row);

	// Get next (row, col) value, and return value and col position. 
	// False if no more values for this  
	bool getNextColAndValue(int & col, double & value);

	// Test & validate method
	bool test();
	
private:
	std::map< int, std::map< int, double> > _matrix;
	std::map< int, std::map< int, double> >::iterator _row;
	std::map< int, double>::iterator _pair;
	int _col;
};

#endif // !defined(AFX_FASTACCESSMATRIX_H__9F05D3BB_5D44_472A_A5BF_8D3ED872BBBC__INCLUDED_)
