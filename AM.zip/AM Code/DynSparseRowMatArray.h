#ifndef DYNSPARSEROWMATARRAY_H
#define DYNSPARSEROWMATARRAY_H

#include "DynSparseRowArray.h"
#include "DynSparseRowArray.cpp"

#include <fstream>
#include <iostream>
#include <vector>
#include <cassert>

template<class T> class DynSparseRowMatArray
{
	public:
		//Constructors
		explicit DynSparseRowMatArray();
		~DynSparseRowMatArray();

		DynSparseRowMatArray(int);
		DynSparseRowMatArray(unsigned rows, unsigned cols);
		DynSparseRowMatArray(unsigned rows, unsigned cols, int state);

		//The following search Ts a pass by reference and a pass by value
		//Note that pass by reference should only be used for assignments

		T operator()(unsigned,unsigned);
		DynSparseRowArray<T>&  operator[](unsigned);

		unsigned nz();//returns number of non zero entries in matrix

		//Utilities
		void clear();//completely clear all entries in mat. at end, Mat is size 0x0
		void deleteAll();

		//Generates SparseLib++ data structures from DynSparseRowMatArray
		void compRowArrayFormat(int& M, int& N, int& NZ, T*& val,int*& r, int*& c);

		unsigned int getNumberOfRows(){return matDims[0];};
		unsigned int getNumberOfColumns(){return matDims[1];};

	private:
		int mat_storage_state;//0 - Vector; 1 - List; 2 - Mixed; 3 - Array

		DynSparseRowArray<T>* matRowsVec;//for vector storage
		static T zero;//We need a zero to return a reference to, so we can let (i,j) return a ref

		//For basic array storage management
		unsigned matDims[2];//holding the dimensions of the array
		static const T minVal;//ensures
};

#endif



