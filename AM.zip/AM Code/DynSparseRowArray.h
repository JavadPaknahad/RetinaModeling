#ifndef DYNSPARSEROWARRAY_H
#define DYNSPARSEROWARRAY_H
template<class T>
class DynSparseRowArray
{
	public:
		explicit DynSparseRowArray();
		~DynSparseRowArray();
		T value(unsigned index);
		T& refValue(unsigned index);
		T& operator[](unsigned index);
		unsigned vecCapacity();
		unsigned totalEntries();
		void fillCompRow(unsigned& count,int NZ,T* val,int* c);
		void clear();
		unsigned length();
		bool empty();
		void deleteAll();
		int changeSize(unsigned);
		T& insert(unsigned index, T value, unsigned arrayPos );

	private:

		T* vecEntries;
		unsigned* vecIndices;
		unsigned vecSize;
		unsigned numEntries;
		static const T minVal;
};


#endif




