#ifndef NODESEQUENCER_H
#define NODESEQUENCER_H

#include <map>

class NodeSquencer
{
	
	public:

		//NodeSequencer();
		//~NodeSequencer();
		
		addNode

	private:


};


#endif