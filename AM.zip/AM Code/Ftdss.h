// Ftdss.h: interface for the CFtdss class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FTDSS_H__70C915DC_1AFE_44C0_AF5B_C0084F89AF7C__INCLUDED_)
#define AFX_FTDSS_H__70C915DC_1AFE_44C0_AF5B_C0084F89AF7C__INCLUDED_


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning (disable:4786)
#include <limits.h>

#include <fstream>

#include <vector>
#include <map>
#include <list>
#include <string>

#include "compcol_double.h"
#include "comprow_double.h"

#include "preconditioner.h"
#include "stub_pre.h"

#include "diagpre_double.h"
#include "ilupre_double.h"
#include "icpre_double.h"

#include "mvvd.h"
#include "mvvi.h"
#include "mvblasd.h"

#include "cg.h"
#include "cheby.h"
#include "bicg.h"
#include "bicgstab.h"

#include "DynSparseRowMatArray.cpp"

#include "Timer.h"
#include "FastAccessMatrix.h"


class CFtdss  
{
public:
	CFtdss();
	virtual ~CFtdss();

	void showHelp(); // Show app help text

	int run(int argc, char* argv[]);	// Solve system as requested from cmd line
										// Return values:
										// 0 = System solved


	bool addCurrentVector( std::string currentfile, std::map<int,	// Reads a current definition file (*.cur)
					  std::vector<double> >& currents,				//  Current file format: 
					  int iterations, double timestep,				//  Header:
					  int node_pos,int node_neg);					//		 % sample_rate	wrapmode
																	//
																	//	where sample_rate is in [samples/s].
																	//	wrapmode: 0=0, 1=wrap around
																	//	then, one value per row, spaced at sample rate.
																	//  This routine linearly interpolates and decimates as needed.

	void calculateDifferentials(CFastAccessMatrix& Geq, 
		double* vvoltage, double* differential,int matrixsize);	
	
	bool saveNodes( std::vector<std::string>& nodetoname, 
		std::map<std::string,int>& nametonode, int& matrixsize, 
		std::string& groundnodename);

	bool recoverNodes( std::vector<std::string>& nodetoname, 
		std::map<std::string,int>& nametonode, int& matrixsize, 
		std::string& groundnodename);

	bool saveMatrix( DynSparseRowMatArray<double>& G, 
		CFastAccessMatrix& Geq, std::map<int, 
		std::vector<double> >& currents);

	bool recoverMatrix( DynSparseRowMatArray<double>& G, 
		CFastAccessMatrix& Geq, std::map<std::string,int>& nametonode, 
		int& matrixsize, std::map<int, std::vector<double> >& currents);

	bool recoverCommandLine(int& nargc, char**& nargv,int argc, 
		char* argv[], bool resumeSimulation);

	bool saveCommandLine(int argc, char* argv[]);

	void showSystem(CompRow_Mat_double& A,VECTOR_double &x, 
		const VECTOR_double& k, int matrixsize);

	int solve(CompRow_Mat_double& A,VECTOR_double &x, 
		const VECTOR_double& k,const CPreconditioner& D,
		int maxit,double tol, int algorithm);

	void writeResultForNode(const char filename[], double& value);

	void writeResultVector(const char filename[], 
		VECTOR_double x, unsigned int size,std::string& groundnodename, 
		std::vector<std::string>& nodetoname);

	int getNodeNumber(std::string& node);

	// Not used.(initial approx for the V vector values)
	// not sure if it is of any use with this method,
	// as the V are overwritten anyway looks like...
	bool loadVoltageVector( std::string& voltagefile, 
		double* v, int size);
	
	double readValue(std::ifstream& file, int wrapmode);

	void updateCurrentVector(double* vcurrent,
		double* vdifferential,int matrixsize);

	void loadCurrentVector( double* vcurrent, int matrixsize, 
		int step, std::map<int, std::vector<double> >& currents);

	void getaliases(std::ifstream& file,
		std::map<std::string,std::string>& aliases);

	std::string translateAlias(std::string& alias,
		std::map<std::string,std::string>& aliases);

	bool getNode(std::ifstream& file,std::string& node);


	bool mapNodes( std::string& networkfile,			// Nodes are mapped using consecutive numbers.
		std::vector<std::string>& nodetoname,			// GND node is considered to be -1 (not used in the matrix)
		std::map<std::string,int>& nametonode, 
		int& matrixsize, std::string& groundnodename);

	bool getElement(std::ifstream& file,char& type,
		std::string& node1,std::string& node2,
		double& value,std::string& sourcename);

	void fillGmatrix(DynSparseRowMatArray<double>&  G, 
		int node_pos, int node_neg, 
		const double& value);

	void fillGeqmatrix(CFastAccessMatrix&  Geq, 
		int node_pos, int node_neg, const double& v, 
		const double& timestep);

	bool loadMatrix( std::string& networkfile, std::string& currentfile,  		// Loads admittance matrix and capacitance matrix,
				DynSparseRowMatArray<double>& G, 								// and setups the current files
				CFastAccessMatrix& Geq, 										// to current sources to nodes mapping.
				std::map<std::string,int>& nametonode,
				int matrixsize, std::map<int, std::vector<double> >& currents, 
				int iterations, double timestep);


	void processCmd(int argc, char* argv[]);		// Process command line options into variables

	void trimString(char* str,int len);


	std::string groundnodename;
	std::vector<std::string> nodetoname; // Node number to name
	std::map<std::string,int> nametonode; // Node name to number
	std::map< int,std::vector<double> > currents;
	std::string tmpA,tmpB,tmpC;
	CTimer timer;

	int maxit;				// Maximum number of iterations
	double tol;			// Numerical tolerance to achieve (default)
	std::string file;
	std::string dumpnode;
	int algorithm;	// Iterative algorithm
	int preconditioner;
	double timestep;
	double duration;
	bool useBoundaryFile;
	bool resumeSimulation;
	bool isStatic;
	
	int   saveevery; // Save results every # iterations
	bool  resumefromVfile; // true = resume simulation by loading existant V file
	std::string resumeVfile; // File to resume from, w/o *.vof extension
	int   resumestep; // Step where to resume from (i.e. which values to use for sources)


};
#endif // !defined(AFX_FTDSS_H__70C915DC_1AFE_44C0_AF5B_C0084F89AF7C__INCLUDED_)
//
