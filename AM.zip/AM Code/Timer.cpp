// Timer.cpp: implementation of the CTimer class.
//
//////////////////////////////////////////////////////////////////////

#include "Timer.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTimer::CTimer()
{
	total=0;
}

CTimer::~CTimer()
{

}

void CTimer::start()
{
	startTime=clock();
}

float CTimer::getElapsedSeconds()
{
	float elapsed = (float) (((float)(clock()-startTime))/(float)CLOCKS_PER_SEC);
	total = total+elapsed;
	return elapsed;
}

float CTimer::getTotal()
{ 
	return total;
}
