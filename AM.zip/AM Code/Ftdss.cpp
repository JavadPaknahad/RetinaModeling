// Ftdss.cpp: implementation of the CFtdss class.
// Carlos J. Cela, 2007-2009
//////////////////////////////////////////////////////////////////////
#pragma warning (disable:4786)

#include "Ftdss.h"
#include "LongHash.h"
#include <iomanip>
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFtdss::CFtdss()
{

}

CFtdss::~CFtdss()
{

}

void CFtdss::showHelp()
{
	std::cout<<"\nUsage:\n\n";
	std::cout<<"    ftdss -f filename [option1] [option2] .... [optionN]\n\n";
	std::cout<<"Options           Description\n";
	std::cout<<"=======           ===========\n\n";

	std::cout<<"-t tol            Set tolerance of solver to tol. Solver will stop iterating\n";
	std::cout<<"                  when the normalized residue is less than tol. Default is 1e-7.\n";
	std::cout<<"-i iter           Set the maximum number of iterations to attempt to solve system.\n";
	std::cout<<"                  Default is the same number as rows calculated for the admittance matrix.\n";
	std::cout<<"-a algorithm      Iterative algorithm to use:\n";
	std::cout<<"                    0 - BiConjugate Gradient [BiCG] (default)\n";
	std::cout<<"                    1 - Conjugate Gradient [CG]\n";
	std::cout<<"                    21 - BiConjugate Gradient Stabilized [BiCGstab]\n";
	std::cout<<"-p pre            Preconditioner to use. Values are:\n";
	std::cout<<"                    0 - Diagonal (default)\n";
	std::cout<<"                    1 - Incomplete LU [ILU]\n";
	std::cout<<"                    2 - Incomplete Choleski [IC]\n";
	std::cout<<"-f filename       Modified SPICE filename (no extension)\n";
	std::cout<<"-d duration       Lenght of simulation, in seconds\n";
	std::cout<<"-s step		      Time step, in seconds\n";
	std::cout<<"-n node           Create MatLab compatible file (*_node_xxx.vof) containing transient voltage waveform for node.\n";
	std::cout<<"-static           Runs only for t=0. The result filename is file.vof (no timestamp).\n";
	std::cout<<"-saveevery steps  Save simulation once every steps steps.\n";
    std::cout<<"-resume file step Resume previous simulation from step step using file file.vof for initial conditions.";
	std::cout<<"\nNote: ftdss will skip R's larger than 1e20 (treating them as open circuits).\n\n";
}

void CFtdss::calculateDifferentials(CFastAccessMatrix& Geq, double* vvoltage,  double* differential,int matrixsize)
{
	int node;
	bool exit=false;
	double value;
	int col,row;

	row=Geq.resetEnumeration();
	while(!exit && row!=-1){
		node=row;
		differential[node]=0.0;

		// Add effects of all caps to this node
		while(Geq.getNextColAndValue(col,value) && !exit ){
			if(node==col){		// Ceq matrix diagonal, cap to ground
				if ( value!=0 )
					differential[node] = differential[node] - ( value * vvoltage[node] ); 
			}else {				// Cap between arbitrary nodes
				if ( value!=0 ){
					double deltav  = ( vvoltage[node]-vvoltage[col] );
					differential[node] = differential[node] - ( value *  deltav ); 
				}
			}

		} 
		row=Geq.nextRow();
		exit=(row==-1);
	}
}
// Header format is: % samples_per_second repeat
// TODO: fix this
/*
bool CFtdss::addCurrentVector( std::string currentfile, std::map<int, std::vector<double> >& currents, int iterations, double timestep, int node_pos,int node_neg)
{
	bool r=false;
	std::vector<double> cvalues;
	double dtmp;
	double thisvalue;
	double prevvalue;
	double fileinterval;
	double value, intervalstart, intervalend,reftime;
	int wrapmode;
	std::string tmp;

	currentfile+=".cur";

	std::ifstream file( currentfile.c_str() );
	if(file.is_open()){
		// Parse header
		file>>tmp;
		file>>fileinterval;
		fileinterval=1.0/fileinterval;
		file>>wrapmode; //0=0, 1=wrap

		// 1st value is for t=0, always is used
		file >> dtmp;
		cvalues.push_back(dtmp);
		prevvalue=cvalues[0];


		// look for the proper previous and next and interpolate linearly
		// or decimate as needed
		int i=1;
		int step=1;
		r=true;
		bool firsttime=true;
		while(step<iterations){

			thisvalue=readValue(file, wrapmode);

			// Evaluate point if inside interval being read
			intervalstart = (i-1) * fileinterval;
			intervalend	  = i * fileinterval;
			if(firsttime){
				reftime = step*timestep;
				firsttime=false;
			}

			while(reftime>=intervalstart && reftime<=intervalend && step<iterations){
				value = (thisvalue-prevvalue)*(reftime-intervalstart)/(intervalend-intervalstart)+prevvalue;
				cvalues.push_back(value);
				step++;
				reftime	= step * timestep;
			}
			prevvalue=thisvalue;
			i++;
		}
		r=true;
		file.close();
	} else {
		std::cout<<"ERROR: File "<<currentfile<<" not found.\n";
		return false;
	}

	// Update currents. If an entry already exists, add to the positive node and subtract to the negative. 
	// this will be the case of multiple current sources connected to one node.
	// Always ignore ground [0], as it is he reference and does not participate in the matrix.
	std::map<int, std::vector<double> >::iterator it;

	if(node_pos!=-1){
		it=currents.find(node_pos);
		if(it==currents.end())
			currents[node_pos]=cvalues;
		else {
			// Add values to existing
			int s = cvalues.size();
			for(int i=0;i<s;i++)
				(it->second)[i]+=cvalues[i];
		}
	}
	if(node_neg!=-1){
		// negate cvalues
		for(std::vector<double>::iterator i=cvalues.begin();i!=cvalues.end();i++)
			(*i)=-(*i);

		it=currents.find(node_neg);
		if(it==currents.end())
			currents[node_neg]=cvalues;
		else {
			// Add values to existing
			int s = cvalues.size();
			for(int i=0;i<s;i++)
				(it->second)[i]+=cvalues[i];
		}
	}
	return r;
}
*/

/*
double CFtdss::readValue(std::ifstream& file, int wrapmode)
{
	double tmp=0.0;
	if(file.eof() || file.bad()){
		if(wrapmode==0)
			return tmp;

		// wrapmode=1: Rewind file
		file.seekg(0,std::ios_base::beg);
		file.clear();
		//Skip header
		std::string tmpstr;
		file>>tmpstr>>tmp>>tmp;
	}
	file>>tmp;
	return tmp;
}
*/

bool CFtdss::addCurrentVector( std::string currentfile, std::map<int, std::vector<double> >& currents, int iterations, double timestep, int node_pos,int node_neg)
{
	bool r=false;
	std::vector<double> cvalues;
	double dtmp;
	std::string tmp1;
	std::string tmp2;
	std::string tmp3;

	currentfile+=".cur";
  std::cout<<"Current file:"<<currentfile<<"\n";

	std::ifstream file( currentfile.c_str() );
	if(file.is_open()){
		// Discard header
		file>>tmp1;
		file>>tmp2;
		file>>tmp3;
		std::cout<<"Current file header:"<<tmp1<<" "<<tmp2<<" "<<tmp3<<"\n";

    // Read file (first value is ALWAYS read
		int step=0;
		while(step<iterations){
		  step++;
		  file >> dtmp;
		  cvalues.push_back(dtmp);	
		  std::cout<<"("<<step<<","<<dtmp<<") ";
		}
		std::cout<<"\n";
		r=true;
		file.close();
	} else {
		std::cout<<"ERROR: Cannot open file "<<currentfile<<".\n";
		return r;
	}
	
	// Update currents. If an entry already exists, add to the positive node and subtract to the negative. 
	// this will be the case of multiple current sources connected to one node.
	// Always ignore ground [0], as it is he reference and does not participate in the matrix.
	std::map<int, std::vector<double> >::iterator it;

	if(node_pos!=-1){
		it=currents.find(node_pos);
		if(it==currents.end())
			currents[node_pos]=cvalues;
		else {
			// Add values to existing
			int s = cvalues.size();
			for(int i=0;i<s;i++)
				(it->second)[i]+=cvalues[i];
		}
	}
	if(node_neg!=-1){
		// negate cvalues
		for(std::vector<double>::iterator i=cvalues.begin();i!=cvalues.end();i++)
			(*i)=-(*i);

		it=currents.find(node_neg);
		if(it==currents.end())
			currents[node_neg]=cvalues;
		else {
			// Add values to existing
			int s = cvalues.size();
			for(int i=0;i<s;i++)
				(it->second)[i]+=cvalues[i];
		}
	}
	return r;
}


void CFtdss::processCmd(int argc, char* argv[])
{
	maxit  = 0;				// Maximum number of iterations
	tol = 1e-7;			// Numerical tolerance to achieve (default)
	file="";
	dumpnode="";
	algorithm=0;	// Iterative algorithm
	preconditioner=0;
	timestep=1e-3;
	duration=0;
	useBoundaryFile=false;
	resumeSimulation=false;
	isStatic=false;
	int xx;

	// Scan for restore option
	for( xx = 1; xx < argc; xx++ ){
		if( strcmp("-r",argv[xx])==0 ){
			std::cout << "Resuming previous simulation...\n";
			resumeSimulation = true;
		}
	}

	// Get parameters (from file or cmd line)
	int nargc;
	char** nargv=0;
	recoverCommandLine( nargc, nargv,argc, argv, resumeSimulation);

	// Use either this command l-ine or saved command line
	if( !resumeSimulation )
		saveCommandLine(argc, argv);

	// Process all other options now
	for( xx = 1; xx < nargc; xx++ ){

		if( strcmp("-t",nargv[xx])==0 )
			tol = atof(nargv[xx+1]);

		if( strcmp("-s",nargv[xx])==0 )
			timestep = atof(nargv[xx+1]);

		if( strcmp("-d",nargv[xx])==0 )
			duration = atof(nargv[xx+1]);

		if( strcmp("-i",nargv[xx])==0 )
			maxit = atoi(nargv[xx+1]);

		if( strcmp("-f",nargv[xx])==0 )
			file = nargv[xx+1];

		if( strcmp("-a",nargv[xx])==0 )
			algorithm = atoi(nargv[xx+1]);

		if( strcmp("-p",nargv[xx])==0 )
			preconditioner = atoi(nargv[xx+1]);

		if( strcmp("-n",nargv[xx])==0 )
			dumpnode = std::string(nargv[xx+1]);

		if( strcmp("-static",nargv[xx])==0 )
			isStatic = true;
			
		if( strcmp("-saveevery",nargv[xx])==0 )
			saveevery = atoi(nargv[xx+1]);
			
		if( strcmp("-resumefilestep",nargv[xx])==0 ){
		  resumeVfile = std::string(nargv[xx+1]);
			resumestep = atoi(nargv[xx+2]);
			resumefromVfile = true;
	  }
			
			

	}

	// Free cml line copy memory
	for( xx=0;xx<nargc;xx++)
		delete nargv[xx];
	delete nargv;
}

int CFtdss::run(int argc, char* argv[])
{
	int result=2; // Default solver method result
	saveevery = 100;
	resumefromVfile = false;


	// Process command line options
	// ============================
	processCmd(argc, argv);

	// Check input files
	// =================
	int matrixsize = 0;
	if(file.empty()){
		std::cout << "Fatal error: Must specify input files." << endl;
		return 2;
	}
	std::string networkfile = file+".net";
	std::string currentfile = file; // Extension added later in the format currentfile_nnnn.cur,
									                // where nnnn is the current source name.
	std::string voltagefile = file; // Extention added later in the format voltagefile_tttttt.vof,
									                // where tttttt is the time from start in microseconds.
	std::ifstream mfile( networkfile.c_str() );
	if(!mfile.is_open()){
		std::cout << "Fatal error: Cannot open network input file " << networkfile << endl;
		return 3;
	}
	mfile.close();

	// Delete dumpnode file if there
	// =============================
	if(!dumpnode.empty()){
		std::string tmp=file+"_node_";
		tmp+=dumpnode;
		tmp+=".vof";
		std::ofstream mfile( tmp.c_str(),std::ios_base::trunc);
		mfile.close();
	}

	// Setup node names
	// ================
	timer.start();
	std::cout << "\nMapping network nodes....\n";
	if( !mapNodes( networkfile, nodetoname, nametonode,matrixsize,groundnodename)){
		std::cout << "ERROR: Ground node not found. Check network and retry...\n";
		return 4;
	}
	std::cout<<"Done in "<<timer.getElapsedSeconds()<<" [s]\n";
	

	// Setup admittance matrix
	// =======================
	CFastAccessMatrix Geq;
	DynSparseRowMatArray<double> G(matrixsize, matrixsize);

	timer.start();
	std::cout << "\nLoading admittance matrix and current vector...\n";
	loadMatrix( networkfile, currentfile, G,Geq, nametonode, matrixsize, currents, (int) ((duration/timestep)+1),timestep);
	std::cout<<"Done in "<<timer.getElapsedSeconds()<<" [s]\n";


	int M, N, NZ;
	double* val = 0;
	int* r      = 0;
	int* c      = 0;

	// Build admittance sparse matrix
	G.compRowArrayFormat(M,N,NZ,val,r,c);
	G.deleteAll();
	CompRow_Mat_double A(M,N,NZ,val,r,c);
	if( val != 0 ) delete [] val;
	if( r != 0 )   delete [] r;
	if( c != 0 )   delete [] c;
	val=0;r=0;c=0;

	// Determine number of iterations
	if(maxit==0) maxit = 2 * matrixsize;

	// Display run parameters
	// ======================
	std::cout<<"\nRun parameters:\n";
	std::cout<<"Numeric tolerance (normalized residue):       "<<tol<<"\n";
	if(isStatic)
		std::cout<<"Static simulation (t=0 only)\n";
	else{
		std::cout<<"ODE solver update algorithm:                  Backward Euler (BE)\n";
		std::cout<<"Simulation duration:                          "<<duration<<" [seconds]\n";
		std::cout<<"Time step:                                    "<<timestep<<" [seconds]\n";
	}
	std::cout<<"Input network file:                           "<<networkfile<<"\n";
	std::cout<<"Input initial conditions (voltage) file:      "<<voltagefile<<"\n";
	std::cout<<"Matrix size (row x col):                      "<<matrixsize<<"x"<<matrixsize<<"\n";

	std::cout<<"Preconditioner:                               ";
	switch(preconditioner){
	case 0: std::cout<<"Diagonal\n";break;
	case 1: std::cout<<"Incomplete LU (ILU)\n";break;
	case 2: std::cout<<"Incomplete Choleski\n";break;
  case 3: std::cout<<"SOR (no preconditioning)\n";break;
	default:
		std::cout<<"*unknown*\n\n ERROR: Verify value of [-p] option in command line.";
		return 5;
	}

	std::cout<<"Iterative algorithm:                          ";
	switch(algorithm){
	case 0: std::cout<<"BiConjugate Gradient (BiCG)\n";break;
	case 1: std::cout<<"Conjugate Gradient (CG)\n";break;
	case 2: std::cout<<"Preconditioned Chebyshev (CHEBY)\n";break;
	case 3: std::cout<<"Successive Overelaxation (SOR)\n";break;
  case 4: std::cout<<"BiConjugate Gradient Stabilized (BiCGstab)\n\n";break;
  default:
		std::cout<<"*unknown*\n\n ERROR: Verify value of [-a] option in command line.\n";
		return 6;
	}
	
	if(!dumpnode.empty())
	  std::cout<<"Saving V for only node: "<<dumpnode<<"\n";
	else
	  std::cout<<"Saving V for all nodes (*.vof) every "<<saveevery<<" steps.\n";
	
	std::cout<<"\n";


	// Initialize current and voltage vectors
	// ======================================
	double* vvoltage = new double [matrixsize];
	double* vcurrent = new double [matrixsize];
	double* vdifferential = new double [matrixsize];
	int step=0;

  int i;
	for(i=0;i<matrixsize;i++){
		vvoltage[i]=0.0;
		vcurrent[i]=0.0;
		vdifferential[i]=0.0;
	}  
	
	// Experimental: resume from V file at given step
  if (resumefromVfile ){
    std::cout<<"Attempting to resume simulation from file "<<resumeVfile<<".vof\n";
    if(loadVoltageVector( resumeVfile, vvoltage, matrixsize)){
      step=resumestep;
      std::cout<<"Success - resuming from step: "<<resumestep;
    } else {
      std::cout<<"Error loading file. Restarting simulation from V=0, step=0.";
      for(i=0;i<matrixsize;i++){
		    vvoltage[i]=0.0;
	    } 
    }
  }
  

	// Main loop
	// =========
	bool exit = false;
	double time=0.0;

	std::cout<<"\nSolving system...\n";
	while(!exit){

		timer.start(); 
		std::cout<<"Step:"<<step<<"\nUpdating vectors..\n";

		// Load current values
		// ===================
		loadCurrentVector( vcurrent, matrixsize, step, currents ); 

		// Calculate differentials
		// =======================
		calculateDifferentials(Geq,vvoltage,vdifferential,matrixsize);

		// Update current vector
		// =====================
		updateCurrentVector(vcurrent,vdifferential, matrixsize);
		
		std::cout<<"Done in "<<timer.getElapsedSeconds()<<" [s]\n";

		// Precondition matrix and solve system
		// ====================================
		timer.start(); 
		std::cout<<"Preconditioning...\n";
		{ // Bracket is just to give scope so memory handling of x & k is automatic
			VECTOR_double x(vvoltage,matrixsize);
			VECTOR_double k(vcurrent,matrixsize);

			switch(preconditioner){
				case 0:{
					DiagPreconditioner_double D(A);
					result = solve(A,x,k,D,maxit,tol,algorithm); 
					break;
					   }
				case 1:{
					CompRow_ILUPreconditioner_double D(A);
					result = solve(A,x,k,D,maxit,tol,algorithm);
					break;
					   }
				case 2:{
					ICPreconditioner_double D(A);
					result = solve(A,x,k,D,maxit,tol,algorithm); 
					break;
					   }
        case 3:{
          // No preconditioner
          StubPreconditioner D;
          result = solve(A,x,k,D,maxit,tol,algorithm); 
					break;
        }
				default:
					result=-2;
					std::cout<<"ERROR: Invalid preconditioner option [-p "<<preconditioner<<"]\n\n";
					exit=true;
					continue;
			}
			std::cout<<"Done in "<<timer.getElapsedSeconds()<<" [s]\n";

			// Copy voltage back to vectors
			int i;
			for(i=0;i<matrixsize;i++)
				vvoltage[i]=x(i);


			// Write system back to file
			// =========================
			if(result==0){
				// Prepare filename & write
				// *** System solution is valid ***
				char vtmp[500];

				if(!dumpnode.empty()){
					// Just one node, one file
					std::map<std::string,int>::iterator it=nametonode.find(dumpnode);
					if(it!=nametonode.end()){
						int node=(*it).second;
						sprintf(vtmp,"%s_node_%s.vof",voltagefile.c_str(),dumpnode.c_str());
						std::cout<<"Node voltage:"<<x(node)<<"\n";

						writeResultForNode(vtmp, x(node));
					} else {
						std::cout<<"ERROR: Node " << dumpnode << " not found\n";
						exit=true;
						result=-7;
					}
				} else {
				  // Save entire model
					if(isStatic) {
						  sprintf(vtmp,"%s.vof",voltagefile.c_str());
						  writeResultVector(vtmp, x, matrixsize,groundnodename, nodetoname);
					}else {			
				    // Save every number of steps only
				    if (  (step % saveevery) == 0 ){
					    // All nodes, one file per step
						  sprintf(vtmp,"%s %d.vof",voltagefile.c_str(),step);//,((float)step)*timestep);
              writeResultVector(vtmp, x, matrixsize,groundnodename, nodetoname);
					  }
					}
				}
			} else {
				std::cout<<"*** WARNING: System solution invalid (code "<<result<<")***\n";
				std::cout << "No output file generated.\n";
				result=-6;
				exit=true;
				continue;
			}
		}


		// Check if all done
		// =================
		if(time>duration || isStatic){
			exit=true;
			continue;
		}

		// Update screen
		// =============
		double remaining=timer.getElapsedSeconds()*(duration/timestep - step)/3600;
		std::cout<<"\r                                     Sim:" <<time<<" [s] Last:"<<timer.getElapsedSeconds()/3600<<" [h] To go:"<<remaining<<" [h]";


		// Note: tap here to make adaptive increments.
		// adaptive increments will require recalculation 
		// of G matrix.
		time=time+timestep;
		step++;
	}
	
	std::cout<<"\n\nEnd of run.\n";

	
	// Clean up
	// ========
	delete [] vvoltage;
	delete [] vcurrent;
	delete [] vdifferential;

	// Delete tmp files
	// ================

	return 0;
}


bool CFtdss::saveNodes( std::vector<std::string>& nodetoname, std::map<std::string,int>& nametonode, int& matrixsize, std::string& groundnodename)
{
	std::ofstream file( "nodes.tmp",std::ios_base::trunc );
	if(!file.is_open()){
		std::cout << "Warning: Cannot create nodes.tmp\n";
		return false;
	}

	// Matrix size and ground name
	file<<groundnodename<<"\n"<<matrixsize<<"\n";

	// Node to name
	file<<nodetoname.size()<<"\n";  //size
	std::vector<std::string>::iterator inodetoname=nodetoname.begin();

	while(inodetoname!=nodetoname.end()){
		file<<(*inodetoname)<<"\n";
		inodetoname++;
	}

	// Name to node
	file<<nametonode.size()<<"\n";  //size
	std::map<std::string,int>::iterator inametonode=nametonode.begin();

	while(inametonode!=nametonode.end()){
		file<<(*inametonode).second<<" "<<(*inametonode).first<<"\n";
		inametonode++;
	}

	file.close();
	return true;
}

bool CFtdss::recoverNodes( std::vector<std::string>& nodetoname, std::map<std::string,int>& nametonode, int& matrixsize, std::string& groundnodename)
{
	std::ifstream file( "nodes.tmp" );
	if(!file.is_open()){
		std::cout << "Warning: Cannot open nodes.tmp\n";
		return false;
	}

	// Matrix size and ground name
	file>>groundnodename>>matrixsize;

	// Node to name
	int size,a,n;
	std::string str;

	file>>size;  //size
	for( a=0;a<size;a++){
		file>> str;
		nodetoname.push_back(str);
	}

	if(nodetoname.size()==size)
		size=0;

	// Name to node
	file>>size;  //size

	for( a=0;a<size;a++){
		file>>n>>str;
		nametonode[str]=n;
	}

	if(nametonode.size()==size)
		size=0;

	file.close();
	return true;
}



bool CFtdss::saveMatrix( DynSparseRowMatArray<double>& G, CFastAccessMatrix& Geq, std::map<int, std::vector<double> >& currents)
{
	return true;
}

bool CFtdss::recoverMatrix( DynSparseRowMatArray<double>& G, CFastAccessMatrix& Geq, std::map<std::string,int>& nametonode, int& matrixsize, std::map<int, std::vector<double> >& currents)
{
	return true;
}

bool CFtdss::recoverCommandLine(int& nargc, char**& nargv,int argc, char* argv[], bool resumeSimulation)
{
	int i;

	if(resumeSimulation){
		std::ifstream file( "cmd.tmp" );
		if(!file.is_open()){
			std::cout << "Warning: Cannot open nodes.tmp\n";
			return false;
		}

		file>>nargc;
		nargv = new char*[nargc];

		char str[500];
		for( i=0;i<nargc;i++){
			file>>str;
			nargv[i]=new char[strlen(str)+1];
			strcpy(nargv[i],str);
		}
	} else {
		nargc=argc;
		nargv = new char*[nargc];
		for( i=0;i<argc;i++){
			nargv[i]=new char[strlen(argv[i])+1];
			strcpy(nargv[i],argv[i]);
		}
	}
	return true;
}
bool CFtdss::saveCommandLine(int argc, char* argv[])
{
	int i;
	std::ofstream file( "cmd.tmp",std::ios_base::trunc );
	if(!file.is_open()){
		std::cout << "Warning: Cannot create cmd.tmp\n";
		return false;
	}

	file<<argc<<"\n";

	for( i=0;i<argc;i++)
		file<<argv[i]<<"\n";

	file.close();
	return true;}



void CFtdss::showSystem(CompRow_Mat_double& A,VECTOR_double &x, const VECTOR_double& k, int matrixsize)
{
	int i,j;
	std::cout<<"Admittance matrix:\n";
	for( i=0;i<matrixsize;i++){
		for( j=0;j<matrixsize;j++)
			std::cout<<A(i,j)<<" ";
		std::cout<<"\n";
	}
	std::cout<<"Current+delta vector (known):\n";
	for( i=0;i<matrixsize;i++){
		std::cout<<k[i]<<"\n";
	}
	std::cout<<"\n";

	std::cout<<"Voltage vector (unknown):\n";
	for( i=0;i<matrixsize;i++){
		std::cout<<x[i]<<"\n";
	}
	std::cout<<"\n\n";
}


int CFtdss::solve(CompRow_Mat_double& A,VECTOR_double &x, const VECTOR_double& k,const CPreconditioner& D,int maxit,double tol, int algorithm)
{
	std::cout<<"Solving...\n";

	int result=-2;
	switch(algorithm){
		case 0:{
			result = BiCG(A,x,k,D,maxit,tol);
			break;
		}
		case 1:{
			result = CG(A,x,k,D,maxit,tol);
			break;
		}
		case 2:{
			result = CHEBY(A,x,k,D,maxit,tol,0.0,1.0);
			break;
		}
		case 3:{
      std::cout<<"SOR not supported yet\n";
      return 0;
			//result = SOR(A,x,k,maxit,tol);
			break;
		}  
    case 4:{
      result = BiCGSTAB(A, x, k, D, maxit, tol);
      break;
    }
		default:{
			result=-2;
			std::cout<<"ERROR: Invalid algorithm option [-a "<<algorithm<<"]\n\n";
		}
	}
	return result;
}

void CFtdss::writeResultForNode(const char filename[], double& value)
{
	std::ofstream file( filename,std::ios::app );
	if(!file.is_open()){
		std::cout << "Fatal error: Cannot write result to file " << filename << endl;
		return;
	}
	file<<value<<"\n";
	file.close();

}


void CFtdss::writeResultVector(const char filename[], VECTOR_double x, unsigned int size,std::string& groundnodename, std::vector<std::string>& nodetoname)
{

	std::ofstream file( filename );
	if(!file.is_open()){
		std::cout << "Fatal error: Cannot write result to file " << filename << endl;
		return;
	}

	file<<groundnodename<<" 0.0\n";
  file<<std::setprecision(16);
	for(int i=0;i<size;i++)
		file<<nodetoname[i]<<" "<<x(i)<<"\n";
	file.close();
}




int CFtdss::getNodeNumber(std::string& node)
{
	int r=-2;						// unknown node (ret=-2)
	std::map<std::string,int>::iterator it=nametonode.find(node);
	if(it!=nametonode.end())		// regular node?
		r=(*it).second;
	else							// ground? (ret=-1)
		if(node==groundnodename)
			r=-1;
	return r;

}

bool CFtdss::loadVoltageVector( std::string& voltagefile, double* v, int size)	 
{
	int i;
	bool r=false;
	char name[200];
	std::string node;
	double value;

	sprintf(name,"%s.vof",voltagefile.c_str());

	for(i=0;i<size;i++)
		v[i]=0.0;

	std::ifstream file( name );
	if(file.is_open()){
		r=true;
		while(!file.eof()){
			file >> node>> value;
			i = getNodeNumber(node);
			if(i>=0)
				v[i]=value;
		}
		file.close();
	}
	return r;
}

void CFtdss::updateCurrentVector(double* vcurrent,double* vdifferential,int matrixsize)
{
	int i;
#ifdef _TRACE
	std::cout<<"\nCurrent vector (from interpolation):\n";
	for(i=0;i<matrixsize;i++){
		if(vcurrent[i]!=0||vdifferential[i]!=0)
			std::cout<<"Current["<<i<<"]="<<vcurrent[i]<<" Diff["<<i<<"]="<<vdifferential[i]<<"\n";
	}
#endif

	for(i=0;i<matrixsize;i++)
		vcurrent[i]+=vdifferential[i];

}

void CFtdss::loadCurrentVector( double* vcurrent, int matrixsize, int step, std::map<int, std::vector<double> >& currents)
{
	int i;
	std::map<int, std::vector<double> >::iterator it;

	for(i=0;i<matrixsize;i++){
		it=currents.find(i);
		if(it!=currents.end()){
			vcurrent[i]=(-1)*((*it).second)[step];
//#ifdef _TRACE
			std::cout<<"\nCurrent vector ["<<i<<"]="<<vcurrent[i]<<"\n";
//#endif
		} else
			vcurrent[i]=0;
	}
}


void CFtdss::getaliases(std::ifstream& file,std::map<std::string,std::string>& aliases)
{
	std::string tmp1,tmp2,tmp3;
	bool exit = false;

	while(!exit)
	{
		while(tmp1!="*" && !exit){
			file>>tmp1;
			if(file.eof()) exit=true;
		}
		file>>tmp2>>tmp3;
		if(tmp2=="voxel"){
			exit=true;
			continue;
		}

		if(tmp3=="nodename"){
			file>>tmp2>>tmp3;
			aliases[tmp3]=tmp2;
			std::cout<<"Mapping node alias '"<<tmp3<<"' to node "<<tmp2<<"\n";
		} 
		tmp1="";
	}
	// Rewind file
	file.seekg(0,std::ios_base::beg);
	file.clear();
}


std::string CFtdss::translateAlias(std::string& alias,std::map<std::string,std::string>& aliases)
{
	std::string node=alias;
	std::map<std::string,std::string>::iterator it;

	it=aliases.find(alias);
	if(it!=aliases.end())
		node=(*it).second;

	return node;
}

bool CFtdss::getNode(std::ifstream& file,std::string& node)
{
	bool r=false;
	bool exit=false;

	// Return 2nd node of previous element
	if(!tmpC.empty()){
		node=tmpC;
		tmpC="";
		return true;
	}
	
	// Or first of this element
	while(!file.eof() && !exit){
    
    while(file.good()) {
      file>>tmpA;	
      // Skip params
      if(tmpA[0]=='*') {
        char s[1000];
        file.getline(s,1000);
      } else {
        break;
      }
    }
      
		if((tmpA[0]=='R' || tmpA[0]=='C' || tmpA[0]=='r' || tmpA[0]=='c')){ 
			file>>tmpB>>tmpC;
			node=tmpB;
			exit=true;
			r=true;
		}
	}
	return r;
}

bool CFtdss::mapNodes( std::string& networkfile, std::vector<std::string>& nodetoname, std::map<std::string,int>& nametonode, int& matrixsize, std::string& groundnodename)
{
	// NOTE: Ground node is not mapped. Node #0 is some other node. 
	std::string tmp;
	std::string node;
	int currentnode=0;
	int i;
	std::map<std::string,std::string> aliases;

	std::ifstream file( networkfile.c_str() );

	// Gets aliases & rewinds file
	getaliases(file, aliases);

	bool gndfound=false;

	// Parse .net file and map every node
	while(getNode(file,tmp)){
		if(tmp!="0"){
			node=translateAlias(tmp,aliases);
			i=getNodeNumber(node);

			// If not there, add
			if(i==-2){
				nodetoname.push_back(node);
				nametonode[node]=currentnode;
				currentnode++;
			}
		} else if(!gndfound){
			// Add ground
			groundnodename = translateAlias(tmp,aliases);
			std::cout<<"Ground found at node "<<groundnodename<<"\n";
			nametonode[tmp]=-1; 
			gndfound=true;
		}
	}
	matrixsize=nodetoname.size();
	file.close();
	return gndfound;
}

void CFtdss::trimString(char* str,int len)
{
	char* tmp;
	tmp = new char[len];
	for(int i=0;i<len;i++){
		if(str[i]>33){
			strcpy(tmp,str+i);
			break;
		}
	}
	strcpy(str,tmp);
	delete [] tmp;
}


bool CFtdss::getElement(std::ifstream& file,char& type,std::string& node1,std::string& node2,double& value,std::string& sourcename)
{
	bool r=false;
	bool exit=false;
	char ch;
	std::string tmp;

	while(!file.eof() && !exit){

		// Skip the spaces
		do{
			file.get(ch);
		}while(!file.eof()&&ch==' ');

		switch(ch){
		case 'R':
		case 'r':
			file>>tmp>>node1>>node2>>value;
			type='R';
			if(value<1e20) // Skip open circuits
				r=true;
			exit=true;
			break;
		case 'C':
		case 'c':
			file>>tmp>>node1>>node2>>value;
			type='C';
			r=true;
			exit=true;
			break;
		case 'I':
		case 'i':
			file>>sourcename>>node1>>node2;
			type='I';
			r=true;
			exit=true;
			break;
		default:
			// Discard line
		    while(!file.eof()&&ch!='\n')
		    	file.get(ch);
			continue;
		}
	}
	return r;
}



void CFtdss::fillGmatrix(DynSparseRowMatArray<double>&  G, int node_pos, int node_neg, const double& value)
{
	if(node_pos!=-1){
		G[node_pos][node_pos] = G(node_pos,node_pos) - 1.0/value;
	}
	if(node_neg!=-1){
		G[node_neg][node_neg] = G(node_neg,node_neg) - 1.0/value;
	}

	if(node_pos!=-1 && node_neg!=-1){
		G[node_pos][node_neg] = G(node_pos,node_neg) + 1.0/value;
		G[node_neg][node_pos] = G(node_neg,node_pos) + 1.0/value;
	}
}


void CFtdss::fillGeqmatrix(CFastAccessMatrix&  Geq, int node_pos, int node_neg, const double& c, const double& timestep)
{
	double geq = c / timestep;
	double value;
	
	// Cap to ground
	if(node_pos==-1){
		Geq.get(node_neg,node_neg,value);
		value+=geq;
		Geq.set(node_neg,node_neg,value);
	}
	if(node_neg==-1){
		Geq.get(node_pos,node_pos,value);
		value+=geq;
		Geq.set(node_pos,node_pos,value);
	}

	// Cap between 2 arbitrary nodes
	if(node_pos!=-1 && node_neg!=-1){
		Geq.get(node_pos,node_neg,value);
		value+=geq;
		Geq.set(node_pos,node_neg,value);

		Geq.get(node_neg,node_pos,value);
		value+=geq;
		Geq.set(node_neg,node_pos,value);
	}
}

bool CFtdss::loadMatrix( std::string& networkfile, std::string& currentfile, 
				DynSparseRowMatArray<double>& G, 
				CFastAccessMatrix& Geq, 
				std::map<std::string,int>& nametonode,
				int matrixsize, std::map<int, std::vector<double> >& currents, 
				int iterations, double timestep)
{
	bool r=false;
	bool exit= false;
	char type;
	double value;
	int node_pos, node_neg;
	std::string sourcename,node1,node2;
	std::ifstream file( networkfile.c_str() );


	// Calculate matrix
	// ====================
	int cs=0,rr=0,cc=0;
	while(!exit && getElement(file,type,node1,node2,value,sourcename))
	{
		// Translate node names to node number
		// ===================================
		bool valid=false;
		std::map<std::string,int>::iterator it;

		if(node1=="0"){
			node_pos=-1; //ground
			valid=true;
		}else{
			it = nametonode.find(node1);
			valid= (it!=nametonode.end());
			if(valid) node_pos=(*it).second;
		}
		if(!valid){
			std::cout<<"ERROR: Node not found when loading matrix. ["<<node1<<"]\n\n";
			exit=true;
			break;
		}

		if(node2=="0"){
			node_neg=-1; //ground
			valid=true;
		}else{
			it = nametonode.find(node2);
			valid= (it!=nametonode.end());
			if(valid) node_neg=(*it).second;
		}
		if(!valid){
			std::cout<<"ERROR: Node not found when loading matrix. ["<<node2<<"]\n\n";
			exit=true;
			break;
		}

		// Fill data structures
		// ====================
		// Note: to save memory, Rceq and R's are considered in parallel. Strictly speaking,
		// the initial conditions for capacitors should be such that they are an open, so Rceq
		// should not be considered in the first time-step. This is too resource intensive for 
		// large models, so in here we are *hoping* the value will converge to a good number
		// in the first couple of iteraions, which should be almost always the case.
		switch(type){
		case 'R':{
			fillGmatrix(G,node_pos,node_neg,value);
			r=true;
			rr++;
			break;
		}
		case 'C':{
		  if (!isStatic){
  			fillGeqmatrix(Geq,node_pos,node_neg,value, timestep);
			  value= (timestep / value);
			  fillGmatrix(G,node_pos,node_neg,value);
			  r=true;
			  cc++;
			}
			break;
		}
		case 'I':{
			r=addCurrentVector( sourcename, currents, iterations, timestep, node_pos, node_neg);
			cs++;
			break;
		}
		default:;
		}
		if((rr+cc)%10000==0)
			std::cout<<"\r"<<rr<<" resistors, "<<cc<<" capacitors and "<<cs<<" current sources parsed...";
	}
	std::cout<<"\r"<<rr<<" resistors, "<<cc<<" capacitors and "<<cs<<" current sources parsed...";
	std::cout<<"\n";
	return r;
}