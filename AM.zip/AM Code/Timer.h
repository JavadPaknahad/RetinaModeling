// Timer.h: interface for the CTimer class.
// Carlos J. Cela, 2006
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TIMER_H__3FCEB896_3F30_4F89_9D62_C79B20D2729A__INCLUDED_)
#define AFX_TIMER_H__3FCEB896_3F30_4F89_9D62_C79B20D2729A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <ctime>
class CTimer  
{
public:
	CTimer();
	virtual ~CTimer();
	
	void start();
	float getElapsedSeconds();
	float getTotal();

private:	
	clock_t startTime;
	float total;
};

#endif // !defined(AFX_TIMER_H__3FCEB896_3F30_4F89_9D62_C79B20D2729A__INCLUDED_)
