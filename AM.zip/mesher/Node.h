//////////////////////////////////////////////////////////////////////
// Node.h: interface for the CNode class.
// Carlos J. Cela, 2010
//////////////////////////////////////////////////////////////////////

#if !defined(NODE_H)
#define NODE_H

#include "Exception.h"


// State of the node
enum{
    ST_INVALID    = 0x00, // Error
    ST_AVAILABLE  = 0x01, // This node can be further clustered
    ST_BOUNDARY   = 0x02, // This node is a boundary node and cannot
                          // be further clustered.
    ST_CLUSTERED  = 0x04, // This node is part of a cluster, and can 
                          // be further clustered
    ST_REPORTED   = 0x08, // Node has already been clustered and reported
};


class CNode  
{
public:
	CNode(short materialCode = -1, short px = -1 , short py = -1, short pz = -1, short sizex = 1, short sizey = 1, short sizez = 1);
  ~CNode();

  short material; // Index of material
  short state;    // Current state of voxel
  
  // Size
  short sx;
  short sy;
  short sz;
  
  // Position
  short x;
  short y;
  short z;

};

#endif // !defined(NODE_H)
