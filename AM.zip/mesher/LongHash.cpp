// LongHash.cpp: implementation of the CLongHash class.
// C.J. Cela, 2004
//////////////////////////////////////////////////////////////////////

#include "LongHash.h"
#include <string>
#include <stdio.h>
#include <stdlib.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CLongHash::CLongHash()
{

}

CLongHash::CLongHash(int cx, int cy, int cz):x(cx),y(cy),z(cz)
{

}

CLongHash::~CLongHash()
{

}
std::string CLongHash::getHash()
{
    char tmp[13];
    sprintf(tmp,"%04d%04d%04d",x,y,z);
    return std::string(tmp);
}
std::string CLongHash::getHash(int x, int y, int z)
{
    char tmp[13];
    sprintf(tmp,"%04d%04d%04d",x,y,z);
    return std::string(tmp);
}
std::string CLongHash::getHash(int x, int y, int z, int index)
{
    char tmp[17];
    // 4 decimal digits
    sprintf(tmp,"%04d%04d%04d%02X",x,y,z,index);
    return std::string(tmp);
}
void CLongHash::getCoordinates(int nodePrefixLen, const std::string& hash, int&x, int&y, int&z)
{
    x = atoi( hash.substr(nodePrefixLen,4).c_str());
    y = atoi( hash.substr(nodePrefixLen+4,4).c_str());
    z = atoi( hash.substr(nodePrefixLen+8,4).c_str());
}


