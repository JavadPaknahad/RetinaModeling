/*
 *  mesh.cpp
 *  mesher
 *
 *  Created by Carlos J. Cela on 7/27/10.
 *  Copyright 2010 The University of Utah. All rights reserved.
 *
 */
//#define DEBUG 

#include "Mesh.h"
#include "LongHash.h"

CMesh::~CMesh()
{
  int i,j,k,i2,j2,k2;
  int x,y,z,sx,sy,sz;
  CNode* n;
  std::cout<<"Cleaning up..."<<std::endl;
  
  for(k=0; k<param->worldSizeZ; k++) {
    for(j=0; j<param->worldSizeY; j++) {
      for(i=0; i<param->worldSizeX; i++) {
        n = getNode(i,j,k);
        if(n) {
          sx = n->sx;
          sy = n->sy;
          sz = n->sz;
          x  = n->x;
          y  = n->y;
          z  = n->z;
          
          delete n;
          
          for(k2=z; k2<z+sz; k2++) {
            for(j2=y; j2<y+sy; j2++) {
              for(i2=x; i2<x+sx; i2++)
                setNode(i2,j2,k2,0);
            }
          }
        }
      }     
    }    
  }
  delete [] mesh;
}

CMesh::CMesh( int resX, int resY, int resZ )
{
  meshSize = resX*resY*resZ;  
  mesh = new CNode*[meshSize];
  
  int i;
  for(i=0;i<meshSize;i++)
    mesh[i] = 0;
  

}

int CMesh::getNodeIndex(int x, int y, int z)
{
  return z*(param->worldSizeY*param->worldSizeX)+y*(param->worldSizeX)+x;
}

void CMesh::setNode(int x, int y, int z, CNode* node)
{
  int index = getNodeIndex(x,y,z);
  mesh[index]=node;
#ifdef DEBUG
  std::cout<<"mesh["<<index<<"] set. Mat="<<node->material<<std::endl;
#endif
}

CNode* CMesh::getNode(int x, int y, int z)
{
  if(x<0 || y<0 || z<0)
    return 0;
  if( x>=param->worldSizeX || y>=param->worldSizeY || z>=param->worldSizeZ )
    return 0; 
  return mesh[getNodeIndex(x,y,z)];
}

void CMesh::markNodeIfBoundary(int x, int y, int z)
{
  CNode* thisNode = getNode(x,y,z);
  CNode* node2;
  
  int i,j,k;
  for( i=x-1;i<=x+1;i+=2) {
    for( j=y-1;j<=y+1;j+=2) {    
      for( k=z-1;k<=z+1;k+=2) {
        node2 = getNode(i,j,k);
        if( node2 && node2->material != thisNode->material) {
          thisNode->state = ST_BOUNDARY;
          return;
        }
      }
    }
  }
}

bool CMesh::cluster( int level )
{
  bool r = false;
  int c = pow(2,level); 
  int i,j,k;
  
  for(k=c/2; k<=param->worldSizeZ; k+=c) {
    for(j=c/2; j<=param->worldSizeY; j+=c) {
      for(i=c/2; i<=param->worldSizeX; i+=c) {
        if(clusterVoxels(i,j,k,c))
          r = true;
      }     
    }    
  }
  return r;
}

int CMesh::getSizeOfSmallestNeighbor(int x, int y, int z, int sx, int sy, int sz)
{
  int s = 100000; // This number can be anything larger than the minimum 
                  // voxel size for the model (in terms of unit voxels).
  int i,j,k;
  for(i=x-1;i<=(x+sx);i++) {
    for(j=y-1;j<=(y+sy);j++) {
      for(k=z-1;k<=(z+sz);k++) {
        // If in 'outside shell' of the voxel
        if( (i==x-1)||(i==x+sx) || (j==y-1)||(j==y+sy)|| (k==z-1)||(k==z+sz) )
          getSmallestSize(i,j,k,s);
      }
    }
  }
  return s;
}

// Returns smallest size in s, only if less than 
// current content of s.
void CMesh::getSmallestSize(int x, int y, int z, int& s)
{
  CNode* node = getNode(x,y,z);
  if( !node )
    return;
  int tmp = smallestOf(node->sx,node->sy,node->sz);
  if ( tmp < s)
    s = tmp;
}

int CMesh::smallestOf(int x, int y, int z)
{
  return (x<y)?((x<z)?x:z):((y<z)?y:z);
}

int CMesh::largestOf(int x, int y, int z)
{
  return (x>y)?((x>z)?x:z):((y>z)?y:z);
}

CNode* CMesh::getNodeIfOrigin(int x, int y, int z)
{
  CNode* node = getNode(x,y,z);
  if( node && (node->x!=x ||node->y!=y ||node->z!=z) )
    node = 0;
  return node;
}

void CMesh::attachX(int index1, int index2)
{
  int i,j,k;
  CNode* n1 = octant[index1];
  CNode* n2 = octant[index2];
  
  // Update pointers
  for( k=n2->z; k<(n2->z+n2->sz); k++ ) {
    for( j=n2->y; j<(n2->y+n2->sy); j++ ) { 
      for( i=n2->x; i<(n2->x+n2->sx); i++ )
        setNode(i,j,k,n1);
    }
  }
  
  // Expand first node
  n1->sx *= 2;
  
  // Delete second node
#ifdef DEBUG
  std::cout<<"deleting.."<<std::endl;
#endif
  delete n2;
  
  // Modify octant now
  for(i=0;i<8;i++){
    if(octant[i]==n2)
      octant[i] = n1;
  }
}

void CMesh::attachY(int index1, int index2)
{
  int i,j,k;
  CNode* n1 = octant[index1];
  CNode* n2 = octant[index2];
  
  // Update pointers
  for( k=n2->z; k<(n2->z+n2->sz); k++ ) {
    for( j=n2->y; j<(n2->y+n2->sy); j++ ) { 
      for( i=n2->x; i<(n2->x+n2->sx); i++ )
        setNode(i,j,k,n1);
    }
  }
  
  // Expand first node
  n1->sy += n2->sy;
  
  // Delete second node
#ifdef DEBUG
  std::cout<<"deleting.."<<std::endl;
#endif
  delete n2;
  
  // Modify octant now
  for(i=0;i<8;i++){
    if(octant[i]==n2)
      octant[i] = n1;
  }
}


void CMesh::attachZ(int index1, int index2)
{
  int i,j,k;
  CNode* n1 = octant[index1];
  CNode* n2 = octant[index2];
  
  // Update pointers
  for( k=n2->z; k<(n2->z+n2->sz); k++ ) {
    for( j=n2->y; j<(n2->y+n2->sy); j++ ) { 
      for( i=n2->x; i<(n2->x+n2->sx); i++ )
        setNode(i,j,k,n1);
    }
  }
  
  // Expand first node
  n1->sz += n2->sz;
  
  // Delete second node
#ifdef DEBUG
  std::cout<<"deleting.."<<std::endl;
#endif
  delete n2;
  
  // Modify octant now
  for(i=0;i<8;i++){
    if(octant[i]==n2)
      octant[i] = n1;
  }
}


void CMesh::list(const char* t, CNode* n)
{
  std::cout<<t;
  std::cout<<"node:"<< n->x <<","<< n->y <<","<< n->z <<" s:"<< n->sx <<","<<n->sy <<","<< n->sz<<std::endl;
}

void CMesh::tryClusterX(bool& r)
{
  int n;
  int seq[] = {0,2,4,6};
  int inc = 1;
  //std::cout<<std::endl<<"Joining X:"<<std::endl;
  for( n=0; n<4; n++) {
    if( checkConstraintsX(octant[seq[n]], octant[seq[n]+inc]) ) {
#ifdef DEBUG
      list("Joining:",octant[seq[n]]);
      list("    and ",octant[seq[n]+inc]);
#endif
      attachX( seq[n], seq[n]+inc );
#ifdef DEBUG
      list("   into ",octant[seq[n]]);   
#endif
      r = true;
    }
  }
}

void CMesh::tryClusterY(bool& r)
{
  int n;
  int seq[] = {0,1,4,5};
  int inc = 2;
  //std::cout<<std::endl<<"Joining Y:"<<std::endl;
  for( n=0; n<4; n++) {
    if( checkConstraintsY(octant[seq[n]], octant[seq[n]+inc]) ) {
#ifdef DEBUG
      list("Joining:",octant[seq[n]]);
      list("    and ",octant[seq[n]+inc]);
#endif
      attachY( seq[n], seq[n]+inc );
#ifdef DEBUG
      list("   into ",octant[seq[n]]);   
#endif
      r = true;
    }
  }
}

void CMesh::tryClusterZ(bool& r)
{
  int n;
  int seq[] = {0,1,2,3};
  int inc = 4;
  //std::cout<<std::endl<<"Joining Z:"<<std::endl;
  for( n=0; n<4; n++) {
    if( checkConstraintsZ(octant[seq[n]], octant[seq[n]+inc]) ) {
#ifdef DEBUG
      list("Joining:",octant[seq[n]]);
      list("    and ",octant[seq[n]+inc]);
#endif
      attachZ( seq[n], seq[n]+inc );
#ifdef DEBUG
      list("   into ",octant[seq[n]]);   
#endif
      r = true;
    }
  }
}

// n1 is always BACK
bool CMesh::checkConstraintsX(CNode* n1, CNode* n2)
{
  bool r = false;
  
  if((n1 && n1->state==ST_BOUNDARY) || (n2 && n2->state==ST_BOUNDARY))
    return r;  
  
  // Check material, existence, that are different voxels
  if( n1 && n2 && (n1!=n2) && (n1->material==n2->material) ){
    
    // Check that voxels are aligned in the orthogonal directions
    if( (n1->y==n2->y) && (n1->sy==n2->sy) &&
       (n1->z==n2->z) && (n1->sz==n2->sz) ) {
    
      // Check that voxels are adjacents
      if( (n1->x+n1->sx)==n2->x ) {
    
        // Check geometric constraints
        if (checkGeometricConstraints(n1->x, n1->y, n1->z, n1->sx*2, n1->sy, n1->sz))
          r = true;
      }
    }
  }
  return r;
}

// n1 is always LEFT
bool CMesh::checkConstraintsY(CNode* n1, CNode* n2)
{
  bool r = false;
  
  if((n1 && n1->state==ST_BOUNDARY) || (n2 && n2->state==ST_BOUNDARY))
    return r;  
  
  // Check material, existence, that are different voxels
  if( n1 && n2 && (n1!=n2) && (n1->material==n2->material) ){
    
    // Check that voxels are aligned in the orthogonal directions
    if( (n1->x==n2->x) && (n1->sx==n2->sx) &&
       (n1->z==n2->z) && (n1->sz==n2->sz) ) {
      
      // Check that voxels are adjacents
      if( (n1->y+n1->sy)==n2->y ) {
        
        // Check geometric constraints
        if (checkGeometricConstraints(n1->x, n1->y, n1->z, n1->sx, n1->sy*2, n1->sz))
          r = true;
      }
    }
  }
  return r;
}

// n1 is always BOTTOM
bool CMesh::checkConstraintsZ(CNode* n1, CNode* n2)
{
  bool r = false;
  
  if((n1 && n1->state==ST_BOUNDARY) || (n2 && n2->state==ST_BOUNDARY))
    return r;
  
  // Check material, existence, that are different voxels
  if( n1 && n2 && (n1!=n2) && (n1->material==n2->material) ){
    
    // Check that voxels are aligned in the orthogonal directions
    if( (n1->x==n2->x) && (n1->sx==n2->sx) &&
       (n1->y==n2->y) && (n1->sy==n2->sy) ) {
      
      // Check that voxels are adjacents
      if( (n1->z+n1->sz)==n2->z ) {
        
        // Check geometric constraints
        if (checkGeometricConstraints(n1->x, n1->y, n1->z, n1->sx, n1->sy, n1->sz*2))
          r = true;
      }
    }
  }
  return r;
}

bool CMesh::clusterVoxels(int x, int y, int z, int sideSize)
{
  bool r = false;
  int step = sideSize/2;
  
  octant[0] = getNodeIfOrigin(x-step, y-step, z-step);
  octant[1] = getNodeIfOrigin(x     , y-step, z-step);
  octant[2] = getNodeIfOrigin(x-step, y     , z-step);
  octant[3] = getNodeIfOrigin(x     , y     , z-step);
  octant[4] = getNodeIfOrigin(x-step, y-step, z     );
  octant[5] = getNodeIfOrigin(x     , y-step, z     );
  octant[6] = getNodeIfOrigin(x-step, y     , z     );
  octant[7] = getNodeIfOrigin(x     , y     , z     );
  
  tryClusterX(r);
  tryClusterY(r);
  tryClusterZ(r);
  
  return r;
}


bool CMesh::checkGeometricConstraints(int x, int y, int z, int sx, int sy, int sz)
{
  bool r = false;
  
  // Pick largest of sides & thisSize
  int maxSizeAfterClustering = largestOf(sx,sy,sz);
  
  // Check all restricted volumes. Clustering ratio is always 2:1.
  // If volumes overlap, use smaller clustering size.
  int targetSize = param->maximumSize;
  
  std::list<CVolume*>::iterator v;
  for( v = param->volume.begin(); v!=param->volume.end(); v++ ) {
    if( (*v)->inVolume(x,y,z)) {
      if((*v)->maxSize<targetSize) {
        targetSize = (*v)->maxSize;
      }
    }
  }
  
	// Check maximum voxel size
  if( sx>targetSize || sy>targetSize || sz>targetSize )
    return false;
  else
    r = true;
  
  // Check neighbors size
  if( r ){
    // Adjacent voxels clustering ratio constraint enforcement
    if( maxSizeAfterClustering > (2 * getSizeOfSmallestNeighbor( x,  y,  z, sx,  sy,  sz)) )
      r = false;
  }
  return r;
}

int CMesh::writeMesh( std::ostream& os )
{
  int num=0;
  int x,y,z;
  CNode* node;
  
  for(z=0; z< param->worldSizeZ; z++) {
    for(y=0; y< param->worldSizeY; y++) {
      for(x=0; x< param->worldSizeX; x++) { 
        node = getNode(x, y, z);
        // Material 0 is not written
        if( (node->material>0) && (node->state!=ST_REPORTED) ){
          node->state = ST_REPORTED;
          num++;
          CLongHash lh(x,y,z);
          os<<lh.getHash()<<" "<< x <<" "<< y <<" "<< z <<" "<< node->sx <<" "<< node->sy <<" "<< node->sz <<" "<< node->material << std::endl;
        }
      }
    }
  }
  return num;
}

