% C.J.Cela, 2005
% Plots effect of guide point params on a
% cluster size vs.distance in voxels graph

function simguide(a,b)
x=1:100;
f=a*x+b*(x.^2);
plot(x,f)