
//////////////////////////////////////////////////////////////////////
// Multiresolution mesher
// Carlos J. Cela
// Revision date: July 20, 2010
//////////////////////////////////////////////////////////////////////

#include "Mesher.h"
#include "FileReader.h"
#include "Exception.h"
#include <iostream>
#include <fstream>
#include "Util.h"
#include <stdlib.h>
#include <string.h>


//Main for mesher.exe
int main(int argc, char* argv[])
{
  int rValue =0;
  CMesher* mesher;

  util::msg("Mesher V6.0\n\nCarlos J. Cela (cjcela@gmail.com)\n\n");
  util::msg("BEGIN RUN\n");

  if( argc < 3 ){
    util::msg("Usage: mesher -f ifile\n");
    util::msg("  where:\n");
    util::msg("    ifile  = *.in file, without extension\n");
    return 1;
  }

  try {
    mesher = new CMesher();

    // Process command line options
    std::string ifilename="";   // Complete *.in  file name

    for( int x = 1; x < argc; x++ ){
      if( strcmp("-f",argv[x])==0 ){ 
        ifilename=argv[x+1];
        ifilename+=".in";
        x++;
      }
    }

    // Process *.in file
    mesher->initialize(ifilename);

    // Multiresolution meshing
    mesher->initMesh();
    mesher->loadMesh();
    mesher->cluster();
    mesher->writeMultiresMesh();
  }
  catch( CException e) {
    // Nothing to do here - CException  
    // constructor will print/log details
    // about what went wrong..
     rValue = 2;
  }
  delete mesher;
  return rValue;
}

