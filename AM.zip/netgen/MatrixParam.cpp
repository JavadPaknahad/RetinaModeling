// MatrixParam.cpp: implementation of the CMatrixParam class.
// C.J. Cela, 2004
//////////////////////////////////////////////////////////////////////

#include "MatrixParam.h"
#include "LongHash.h"
#include "Exception.h"
#include <stdlib.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CMatrixParam::CMatrixParam( std::string inFileName)
{
    CFileReader fp;
    if(!fp.open(inFileName))
        throw CException("Cannot open infile");
    initialize(fp);
    fp.close();
    if( !isValid() )
        throw CException("Invalid parameters in infile");
}

CMatrixParam::CMatrixParam( CFileReader& file )
{
    initialize(file);
}

// Note: Parsing order IS RELEVANT. Do not change
//       unless you understand the dependencies.
void CMatrixParam::initialize(CFileReader& file)
{
    valid = true;
    parseFileParams(file);
    parseWorldParams(file);
    parseRegionParams(file);
    parseVoxelParams(file);    
    parseMaterialParams(file);
    parseClusteringParams(file);
    debugDump();
}

CMatrixParam::~CMatrixParam()
{
    std::map<const int, CMaterial*>::iterator i;
    for( i = material.begin(); i!=material.end(); i++ )
        delete i->second;
    material.clear();

    std::map<std::string, std::string*>::iterator n;
    for( n = nodeName.begin(); n!=nodeName.end(); n++ )
        delete n->second;
    nodeName.clear();
    for( n = nodeAlias.begin(); n!=nodeAlias.end(); n++ ){
        delete n->second;
    }
    nodeAlias.clear();

    std::list<CVolume*>::iterator v;
    for( v = volume.begin(); v!=volume.end(); v++ )
        delete *v;
    volume.clear();

    std::list<std::string*>::iterator s;
    for( s = spice.begin(); s!=spice.end(); s++ )
        delete *s;
    spice.clear();

}

bool CMatrixParam::isValid()
{
    return valid;
}

void CMatrixParam::debugDump()
{
    // Material list
    util::msg("\nMaterial list:");
    std::map<const int, CMaterial*>::iterator i;
    for( i = material.begin(); i!=material.end(); i++ ){
        util::msg()<<"Material:"<<i->first
            <<" x="<< i->second->rhox <<" "<< i->second->erx
            <<" y="<<i->second->rhoy<<" "<<i->second->ery
            <<" z="<<i->second->rhoz<<" "<<i->second->erz
            <<"\n";
    }

    // Volume list
    util::msg("\nVolume list:");
    util::msg()<<"World: max voxel size ="
        <<maximumSize
        <<" x size="<<worldSizeX
        <<" y size="<<worldSizeY
        <<" z size="<<worldSizeZ
        <<" x offset="<<worldOffsetX
        <<" y offset="<<worldOffsetY
        <<" z offset="<<worldOffsetZ
        <<"\n";

   std::list<CVolume*>::iterator v;
   for( v = volume.begin(); v!=volume.end(); v++ ){
        util::msg()<<"Volume: max voxel size="<<(*v)->maxSize
            <<" x="<<(*v)->px
            <<" y="<<(*v)->py
            <<" z="<<(*v)->pz
            <<" size x="<<(*v)->sx
            <<" size y="<<(*v)->sy
            <<" size z="<<(*v)->sz
            <<" c ratio="<<(*v)->clusteringRatio
            <<"\n";
    }
    // Named node list
   if( nodeName.begin()!=nodeName.end()){
       util::msg("\nNamed node list:");
       std::map<std::string, std::string*>::iterator n;
        for( n = nodeName.begin(); n!=nodeName.end(); n++ ){
            util::msg()<<n->first
                <<" "<<*(n->second)
                <<"\n";
       }
   }

}

int CMatrixParam::getWorldSize()
{
    int size = (worldSizeX>worldSizeY)?worldSizeX:worldSizeY;
    size     = (worldSizeZ>size)?worldSizeZ:size;
    return size;
}

std::string CMatrixParam::getDefaultFilename(){
    return inFile.substr(0,inFile.length()-3);
}

void CMatrixParam::parseFileParams(CFileReader& file)
{
    inFile = file.getFileName();
    valid = true;
    if( !file.getNextLine(std::string("matrix"))){
        util::error("matrix declaration not found.");
        valid = false;
        return;
    } 
    file.getStringValue(matrixFile);
    util::msg()<<"Matrix file:"<<matrixFile<<"\n";

    file.gotoBof();
    if( !file.getNextLine(std::string("ispreadfile"))){
       ispreadFile = getDefaultFilename()+".ispr";
       util::warning()<<"ispreadfile declaration not found. Assuming "<<ispreadFile<<"\n";
    } else
           file.getStringValue(ispreadFile);
    util::msg()<<"ispreadfile:"<<ispreadFile<<"\n";

    file.gotoBof();
    if( !file.getNextLine(std::string("nodevoltagefile"))){
       nodeVoltageFile = getDefaultFilename()+".lis3";
       util::warning()<<"nodevoltagefile declaration not found. Assuming "<<nodeVoltageFile<<"\n";
    } else
           file.getStringValue(nodeVoltageFile);
    util::msg()<<"nodevoltagefile:"<<ispreadFile<<"\n";

    file.gotoBof();
    if( !file.getNextLine(std::string("meshfile"))){
       meshFile = getDefaultFilename()+".mrm";
       util::warning()<<"meshfile declaration not found. Assuming "<<meshFile<<"\n";
    } else
           file.getStringValue(meshFile);
    util::msg()<<"meshfile:"<<meshFile<<"\n";

    file.gotoBof();
    if( !file.getNextLine(std::string("networkfile"))){
       networkFile = getDefaultFilename()+".net";
       util::warning()<<"networkfile declaration not found. Assuming "<<networkFile<<"\n";
    } else 
           file.getStringValue(networkFile); 
    util::msg()<<"networkfile:"<<networkFile<<"\n";

    file.gotoBof();
     if( !file.getNextLine(std::string("loadbehavior"))){
        loadBehavior = 0;
        util::warning()<<"loadbehavior declaration not found. Ignoring/Recalculating multirresolution file if present.\n";
    } else 
        loadBehavior = file.getInt();
    util::msg()<<"Load behavior:"<<loadBehavior<<"\n";
}

void CMatrixParam::parseWorldParams(CFileReader& file)
{
    file.gotoBof();
    if( !file.getNextLine(std::string("world"))){
        util::warning("World declaration not found. Using entire file.");
        worldSizeX = 0;
        worldSizeY = 0;
        worldSizeZ = 0;
        worldOffsetX = 0;
        worldOffsetY = 0;
        worldOffsetZ = 0;
    } else {
        worldSizeX = file.getInt();
        worldSizeY = file.getInt();
        worldSizeZ = file.getInt();
        worldOffsetX = file.getInt();
        worldOffsetY = file.getInt();
        worldOffsetZ = file.getInt();
    }
}
void CMatrixParam::parseRegionParams(CFileReader& file)
{
    file.gotoBof();
    while( file.getNextLine(std::string("volume")) ){
        CVolume* v = new CVolume();
        v->maxSize = file.getInt();
        v->sx = file.getInt();
        v->sy = file.getInt();
        v->sz = file.getInt();
        v->px = file.getInt();
        v->py = file.getInt();
        v->pz = file.getInt();
        v->clusteringRatio = file.getInt(); // TODO: Remember this must be 2 for now bc of NETGEN

        volume.push_back(v);
    }
}
void CMatrixParam::parseMaterialParams(CFileReader& file)
{
    //Parse default material
    file.gotoBof();
    if( !file.getNextLine(std::string("defaultmaterial"))){
        util::warning("defaultmaterial not defined.");
        defaultMaterial = -1;
    } else 
        defaultMaterial = file.getInt();

    //Parse materials list

    file.gotoBof();
    while( file.getNextLine(std::string("material")) ){
        int key = file.getInt();
        float xr = file.getFloat();
        float xi = file.getFloat();
        float yr = file.getFloat();
        float yi = file.getFloat();
        float zr = file.getFloat();
        float zi = file.getFloat();

        CMaterial* m = new CMaterial(xr,xi,yr,yi,zr,zi);
        material[key] = m;
    }
    if( material.empty() ){
        util::warning("Not materials defined in *.in file.");
        valid = false;
    }

    //Parse node prefix
    file.gotoBof();
    if( !file.getNextLine(std::string("nodeprefix"))){
       util::warning("nodeprefix not defined. Assuming no prefix.");
       nodePrefix = "";
    } else 
        file.getStringValue(nodePrefix);
    nodePrefixLen = nodePrefix.length();

    // Parse model frequency here
    file.gotoBof();
    if( !file.getNextLine(std::string("frequency"))){
       util::warning("frequency not defined. Assuming DC [0 Hz].");
       frequency = 0.0f;
    } else 
        frequency = file.getFloat();


    // Parse aliases here 
    CLongHash lh;
    int x,y,z;

    file.gotoBof();
    std::string* name;
    while( file.getNextLine(std::string("nodename"))){

        x = file.getInt();
        y = file.getInt();
        z = file.getInt();

        name = new std::string();
        file.getStringValue(*name);

        std::string* autoName = new std::string(lh.getHash(x,y,z));

        nodeName[(*autoName)]=name;
        nodeAlias[(*name)] = autoName;
    }


    // Parse SPICE commands here. 
    // Format is: spice token1 token2.....
    //
    // Replace token   by
    // [node x y z]    node hash
    file.gotoBof();
    std::string line;
    while( file.getNextLine(std::string("spice"))){

        file.getCurrentLine(line);
        //replaceFloatToken(cs,"[frequency",frequency);
        replaceNodeNames(line);
        spice.push_back( new std::string(line) );
    }
    if ( spice.empty() )
        util::warning("no current sources (or other SPICE active elements) defined.");



}
void CMatrixParam::replaceNodeNames(std::string& cs)
{
    std::string r;
    std::string::size_type posE1; //Erase
    std::string::size_type posE2;
    std::string::size_type posN1; //Number
    std::string::size_type posN2;
    int x,y,z;
    CLongHash lh;

    while( true ){
        posE1 = cs.find("[node ",0);

        if( posE1==std::string::npos )
            break;

        posE2 = cs.find("]",posE1);

        posN1 = cs.find_first_not_of(" ",posE1+5);
        posN2 = cs.find_first_of(" ",posN1);
        x=atoi(cs.substr(posN1,posN2-posN1).c_str());

        posN1 = cs.find_first_not_of(" ",posN2);
        posN2 = cs.find_first_of(" ",posN1);
        y=atoi(cs.substr(posN1,posN2-posN1).c_str());

        posN1 = cs.find_first_not_of(" ",posN2);
        posN2 = cs.find_first_of(" ]",posN1);
        z=atoi(cs.substr(posN1,posN2-posN1).c_str());

        
        cs.erase(posE1,posE2-posE1+1);

        //Get alias (if any) &
        //prepend prefix (if not alias)
        std::string nodeName = lh.getHash(x,y,z);
        if(hasAlias(nodeName))
            nodeName=getNodeAlias(nodeName);
        else
            nodeName=nodePrefix+nodeName;

        cs.insert(posE1,nodeName);
    }
}

void CMatrixParam::parseVoxelParams(CFileReader& file)
{
    file.gotoBof();
    if( !file.getNextLine(std::string("unitvoxelsize"))){
       util::warning("unitvoxel size declaration not found. Assuming 1 meter.");
       unitVoxelSize = 1.0f;
    } else 
        unitVoxelSize = file.getFloat();
    file.gotoBof();
     if( !file.getNextLine(std::string("maximumsize"))){
        maximumSize = 16;
        util::warning()<<"maximumsize declaration not found. Assuming "<< maximumSize <<".\n";
    } else 
        maximumSize = file.getInt();
	}
void CMatrixParam::parseClusteringParams(CFileReader& file)
{
    file.gotoBof();
    if( !file.getNextLine(std::string("boundarycriteria"))){
       util::warning("boundary criteria declaration not found. Assuming 0.");
       boundaryCriteria = 0;
    } else 
        boundaryCriteria = file.getInt();

    file.gotoBof();
    if( !file.getNextLine(std::string("clusteringgeometry"))){
       util::warning("clusteringgeometry declaration not found. Assuming 1.");
       clusteringGeometry = 1;
    } else 
        clusteringGeometry = file.getInt();


    // TODO: This version has CLUSTERING RATIO default to 2, because that
    // is the only value supported by NETGEN right now. To be changed when/if
    // NETGEN support other values...
    file.gotoBof();
    if( !file.getNextLine(std::string("clusteringratio"))){
       util::warning("clustering ratio declaration not found. Assuming 2.");
       clusteringRatio = 2;
    } else 
        clusteringRatio = file.getInt();

}
bool CMatrixParam::hasAlias(std::string& name){
    std::map<std::string, std::string*>::iterator it;
    it = nodeName.find(name);

    if( it==nodeName.end() )
        return false;
    return true;
}

const std::string& CMatrixParam::getNodeName(std::string& alias)
{
    std::map<std::string, std::string*>::iterator it;
    it = nodeAlias.find(alias);

    if( it==nodeAlias.end() )
        return alias;
    else
        return *(it->second);
  
}
const std::string& CMatrixParam::getNodeAlias(std::string& name)
{
    std::map<std::string, std::string*>::iterator it;
    it = nodeName.find(name);

    if( it==nodeName.end() )
        return name;
    else
        return *(it->second);
}
