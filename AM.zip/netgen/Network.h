// Network.h
// Carlos J. Cela
//
// Last Revision: Carlos J. Cela, Aug 9 2010
//////////////////////////////////////////////////////////////////////

#if !defined(NETWORK_H)
#define NETWORK_H

#include <string>
#include <fstream>
#include <complex>
#include "MatrixParam.h"

class CNetwork  
{
public:
	CNetwork(CMatrixParam* p);
	virtual ~CNetwork();

  // Loads MR model and writes network file
  void loadAndWrite(std::ostream& file);
  void calculateAndWriteImpedanceValues(std::ostream& file, int x, int y, int z, int sx, int sy, int sz, int material);
  
protected:
  CMatrixParam* param;
  void writeImpedance(std::ostream& file);
  double r;
	double c;
  std::string node1;
  std::string node2;
};

#endif // !defined(NETWORK_H)
