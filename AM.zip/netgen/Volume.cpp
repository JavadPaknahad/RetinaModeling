// Volume.cpp: implementation of the CVolume class.
// C.J. Cela, 2004
//////////////////////////////////////////////////////////////////////

#include "Volume.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CVolume::CVolume():px(0),py(0),pz(0),sx(0),sy(0),sz(0),maxSize(0),clusteringRatio(0)
{
}

CVolume::~CVolume()
{

}

bool CVolume::inVolume(int x, int y, int z)
{
    return ( x>=px && x<=(px+sx) && y>=py && y<=(py+sy) && z>=pz && z<=(pz+sz) );
}

