//////////////////////////////////////////////////////////////////////
// Miscelaneous utility routines, used all over the place
// Carlos J. Cela, 2004
//////////////////////////////////////////////////////////////////////
#ifndef UTIL_CJC_
#define UTIL_CJC_

#include <iostream> 
namespace util
{
    std::ostream&  warning( const char* m = 0);
    std::ostream& error( const char* m=0);
    std::ostream& msg( const char* m = 0);

    bool fileExist( const std::string file);
    std::string getPath(std::string fileName);

}

#endif