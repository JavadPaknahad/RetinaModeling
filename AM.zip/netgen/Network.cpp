// Network.cpp: implementation of the CNetwork class.
// Carlos J. Cela
//
// Last Revision: Carlos J. Cela, 2010
//////////////////////////////////////////////////////////////////////

#include "Network.h"
#include "Exception.h"
#include "LongHash.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CNetwork::CNetwork(CMatrixParam* p )
{
  param = p;
}

CNetwork::~CNetwork()
{
}

void CNetwork::writeImpedance(std::ostream& file)
{
  // Replace nodenames as needed
  node1 = param->getNodeAlias(node1);
  node2 = param->getNodeAlias(node2); 
  
  // Resistor
	if( r < 1E20 ) // Write if not an open
		file<<"Res "<<node1<<" "<<node2<<" "<<r<<"\n";

  // Capacitor
  if( c>0 ) 
		file<<"Cap "<<node1<<" "<<node2<<" "<<c<<"\n";

}

void CNetwork::loadAndWrite(std::ostream& file)
{
  util::msg()<<"\nLoading from multi-resolution mesh file...\n";
  
  // Clear to load here
  CFileReader fp;
  if(!fp.open(param->meshFile))
    throw CException("Cannot open multi-resolution mesh file");
 
  // Rewind & load file
  int x,y,z,sx,sy,sz,m;
  fp.gotoBof();
  
  int count=0;
  while(fp.getNextLine()){
    count++;
    fp.getInt(); // Skip voxel ID
    x  = fp.getInt();
    y  = fp.getInt();
    z  = fp.getInt();
    sx = fp.getInt();
    sy = fp.getInt();
    sz = fp.getInt();
    m  = fp.getInt();
    calculateAndWriteImpedanceValues( file, x, y, z, sx, sy, sz, m);
    if(count%25000 == 0)
      util::msg()<<"\r"<<count;;
  }
  fp.close();
  util::msg()<<"\nModel processed ("<<count<<" voxels).\n";
}



void CNetwork::calculateAndWriteImpedanceValues(std::ostream& file, int x, int y, int z, int sx, int sy, int sz, int material)
{
  CLongHash hash;
  try{
    // Get voxel material parameters
    std::map<const int, CMaterial*>::iterator mat;
    mat = param->material.find(material);
    if( mat==param->material.end()){
      // Unknown material - attempt to use default material
      mat =  param->material.find(param->defaultMaterial);
      if( mat==param->material.end())
        throw CException("Material not found, and no default defined in *.in file");
    }
    
    // Material properties 
    const double eps = 8.8541878176e-12;
    double rhoX,rhoY,rhoZ;
		double epsX,epsY,epsZ;
    
    rhoX = (*mat).second->rhox;
    rhoY = (*mat).second->rhoy;
    rhoZ = (*mat).second->rhoz;
    
    epsX = (*mat).second->erx * eps;
    epsY = (*mat).second->ery * eps;
    epsZ = (*mat).second->erz * eps;
    
    // Get sizes
    double deltaX, deltaY, deltaZ;
    double a; // Transversal area
    double d; // Length
    
    deltaX = sx * param->unitVoxelSize;
    deltaY = sy * param->unitVoxelSize;
    deltaZ = sz * param->unitVoxelSize;
    
    // Write voxel header
    file<<"\n* voxel "<<x<<" "<<y<<" "<<z<<" "<<sx<<" "<<sy<<" "<<sz<<" "<<material<<"\n";
    
    // Process X axis ////////////////////////////////
    a = (0.5 * deltaY) * (0.5 * deltaZ); 
    d = deltaX;
    
		r = rhoX * d / a;
		c = epsX * a / d;
    
    node1 = hash.getHash(x   , y, z);
    node2 = hash.getHash(x+sx, y, z);
    writeImpedance(file);
    
    node1 = hash.getHash(x   , y+sy, z);
    node2 = hash.getHash(x+sx, y+sy, z);
    writeImpedance(file);
    
    node1 = hash.getHash(x   , y, z+sz);
    node2 = hash.getHash(x+sx, y, z+sz);
    writeImpedance(file);
    
    node1 = hash.getHash(x   , y+sy, z+sz);
    node2 = hash.getHash(x+sx, y+sy, z+sz);
    writeImpedance(file);
    
    // Process Y axis ////////////////////////////////
    a = (0.5 * deltaX) * (0.5 * deltaZ); 
    d = deltaY;
    
		r = rhoY * d / a;
		c = epsY * a / d;
    
    node1 = hash.getHash(x   , y   , z);
    node2 = hash.getHash(x   , y+sy, z);
    writeImpedance(file);
    
    node1 = hash.getHash(x+sx, y   , z);
    node2 = hash.getHash(x+sx, y+sy, z);
    writeImpedance(file);
    
    node1 = hash.getHash(x   , y   , z+sz);
    node2 = hash.getHash(x   , y+sy, z+sz);
    writeImpedance(file);
    
    node1 = hash.getHash(x+sx, y   , z+sz);
    node2 = hash.getHash(x+sx, y+sy, z+sz);
    writeImpedance(file);
    
    // Process Z axis ////////////////////////////////
    a = (0.5 * deltaX) * (0.5 * deltaY); 
    d = deltaX;
    
		r = rhoZ * d / a;
		c = epsZ * a / d;
    
    node1 = hash.getHash(x   , y   , z   );
    node2 = hash.getHash(x   , y   , z+sz);
    writeImpedance(file);
    
    node1 = hash.getHash(x+sx, y   , z   );
    node2 = hash.getHash(x+sx, y   , z+sz);
    writeImpedance(file);
    
    node1 = hash.getHash(x   , y+sy, z   );
    node2 = hash.getHash(x   , y+sy, z+sz);
    writeImpedance(file);
    
    node1 = hash.getHash(x+sx, y+sy, z   );
    node2 = hash.getHash(x+sx, y+sy, z+sz);
    writeImpedance(file);
  }
  catch (CException e){
    util::error()<<"\n\nMissing material: "<<material<<" undefined in *.in file.\n";
    throw e;
  }
}
